//
//  Book1+CoreDataProperties.swift
//  MyApplication
//
//  Created by Арина Зубкова on 22.05.17.
//  Copyright © 2017 Арина Зубкова. All rights reserved.
//

import Foundation
import CoreData


extension Book1 {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Book1> {
        return NSFetchRequest<Book1>(entityName: "Book1");
    }

    @NSManaged public var name: String?

}
