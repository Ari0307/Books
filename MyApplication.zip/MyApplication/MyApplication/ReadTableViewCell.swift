//
//  ReadTableViewCell.swift
//  MyApplication
//
//  Created by Арина Зубкова on 29.04.17.
//  Copyright © 2017 Арина Зубкова. All rights reserved.
//

import UIKit

class ReadTableViewCell: UITableViewCell {

    

    @IBOutlet weak var bookNameLabel: UILabel!
    @IBOutlet weak var infoButton: UIButton!
    
}
