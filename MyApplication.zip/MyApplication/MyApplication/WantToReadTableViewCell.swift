//
//  WantToReadTableViewCell.swift
//  MyApplication
//
//  Created by Арина Зубкова on 01.05.17.
//  Copyright © 2017 Арина Зубкова. All rights reserved.
//

import UIKit

class WantToReadTableViewCell: UITableViewCell {

    @IBOutlet weak var bookNameLabel: UILabel!
    @IBOutlet weak var infoButton: UIButton!

}
