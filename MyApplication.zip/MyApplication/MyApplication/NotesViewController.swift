//
//  NotesViewController.swift
//  MyApplication
//
//  Created by Арина Зубкова on 29.04.17.
//  Copyright © 2017 Арина Зубкова. All rights reserved.
//

import UIKit

class NotesViewController: UIViewController {

    
    @IBOutlet weak var notesTextField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
}
