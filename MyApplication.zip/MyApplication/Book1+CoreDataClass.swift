//
//  Book1+CoreDataClass.swift
//  MyApplication
//
//  Created by Арина Зубкова on 22.05.17.
//  Copyright © 2017 Арина Зубкова. All rights reserved.
//

import Foundation
import CoreData

@objc(Book1)
public class Book1: NSManagedObject {

}
